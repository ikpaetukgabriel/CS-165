/***********************************************************************
 * File:lander.cpp
 ***********************************************************************/

#include "lander.h"

#include <iostream>
using namespace std;

Lander:: Lander()
{
    point = Point(0.0,100.0);
}

void Lander::applyGravity(float gravity){
    
}
void Lander::applyThrustLeft(){
    
}
void Lander::applyThrustRight(){
    
}
void Lander::applyThrustBottom(){
    
}

void Lander::advance(){
    
}
void Lander::draw(){
    drawLander(point);
}

